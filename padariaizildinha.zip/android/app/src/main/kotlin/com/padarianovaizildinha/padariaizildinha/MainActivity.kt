package com.padarianovaizildinha.padariaizildinha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
